Georgia refused to exchange Ossetian prisoners for Georgians captured by South Ossetia.
Saakashvili asked Russia to help reunite South Ossetia and Abkhazia with Georgia.
He told the Council of Europe that autonomy for South Ossetia and Abkhazia would comprise "a local government elected freely and directly, that would include an executive branch and a parliament".
Georgia and Moldovia issued a joint declaration against separatist movements.
Saakashvili called for a "new Yalta conference", to extend "liberty" throughout the Black Sea region.
Georgia and Abkhazia met with a UN envoy to form a joint group to manage mine removal and ceasefire violations.
