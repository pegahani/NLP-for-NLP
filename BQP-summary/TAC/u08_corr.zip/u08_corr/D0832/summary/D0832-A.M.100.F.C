By July 2005 U.S. Representative Randall Cunningham was under investigation by the FBI, U.S. Attorney's Office, Defense Criminal Investigative Service, the IRS and a federal grand jury probe.
He received defense contractor MZM Inc's PAC money and personal donations from MZM President, Mitchell Wade.
Wade paid a supposedly inflated price for Cunningham's and Cunningham paid Wade questionably little money to live on Wade's yacht in DC.
Cunningham promoted MZM defense contracts, contributed to and served on a Wade-run charity board, and spoke at an MZM company party.
Cunningham requested donors' permission to transfer campaign funds to his legal defense fund.
