On October 27, 2005 in Paris suburb Clich-sous-Bois, two youth were electrocuted and one injured hiding in a power substation from police.
For 12 days riots reached nearly 300 towns and urban Paris.
A Clichy-sous-Bois mosque was tear gassed.
Buildings were vandalized or firebombed.
Paris airport trains halted.
Thousands of riot police used tear gas and rubber bullets.
A woman was torched.
A beaten man died.
Over 30 police and firemen were injured, two shot.
Nationwide, the nights of November 4 - 7 saw 750, 1,295, 1,408, and 1,173 torched vehicles; 200, 312, 395, and 330 arrests.
Bloggers incited violence.
