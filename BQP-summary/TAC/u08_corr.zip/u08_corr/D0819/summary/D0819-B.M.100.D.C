After long police absence, Sarkozy's October 19 declaration of "war without mercy" on violent suburbs fueled the riots starting October 27.
On November 8, France declared a state of emergency, and offered social assistance.
By November 11, 118 residents, police, firefighters, and foreign journalists were injured, with $US 235 million total damage.
By November 13, torched vehicles exceeded 8,000 and arrests exceeded 2,200.
Vehicle torchings and arrests, respectively, November 1 - 12 were: 180/34, ?/?, 517/78, 897/250, 1300/349, 1408/395, 1173/330, 617/?, 482/?, 325/?, 384/162, 315/161.
(Before the riots, 3,500 vehicles burned monthly nationwide).
France extended emergency powers on November 14.
