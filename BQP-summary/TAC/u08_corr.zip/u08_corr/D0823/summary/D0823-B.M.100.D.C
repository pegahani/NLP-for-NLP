The Ukraine Supreme Court invalidated the November 21 election, due to election fraud.
Yushchenko's ingested poison was identified as pure TCDD, a rare highly toxic form of Dioxin.
Yushchenko deferred criminal investigations until after the repeat election December 26.
Parliament failed to pass Yuschenko's election reforms, but the Constitutional Court ruled for expanded home voting, which helped Yushchenko.
Yushchenko supporters pushed for Yanukovich's resignation; instead he took a leave of absence to run his campaign.
The dual U.S.-Ukraine citizen Yushchenko won the Presidency 51.99% to 44.20% for Yanukovich.
Yanukovich said he would appeal to the Supreme Court, without much hope.
