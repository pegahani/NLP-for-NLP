Seniors are daunted by comparing their current coverage with Part D, baffled by hundreds of complex options, and fearful of picking the wrong Part D plan with wide-ranging premiums and unpredictable coverage changes, potentially costing them several thousands of dollars more annually.
Only 6% of Medicare beneficiaries visited the balky web-based Part D plan selection tool.
Many drug companies will stop offering free or subsidized promotional drugs to needy seniors.
Increased competition among Part D private providers lowered some premiums, but a Senate report showed Part D drug prices are 3% higher than CostCo and Drugstore.com; 60% higher than Canada.
