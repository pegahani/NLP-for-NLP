Medicare Part D enrollment for Medicare beneficiaries began November 15, 2005 though May 15, 2006 for coverage starting January 1, 2006, with a 1% penalty per month for late enrollment.
The Part D Drug Discount Card expired May 15.
After a $100-million information campaign, 33% of seniors felt informed; 37% thought they would benefit.
Seniors choosing a Medicare Part D-approved private drug insurance plan risk loosing their other medical insurance.
Employers used Part D federal subsidies to reduce retirees' overall health premiums; others dropped retiree health plans entirely.
Of 40 million elderly Medicare beneficiaries, 28 million will enter Part D.
