The second round of AU-lead peace talks in Abuja that was temporarily suspended on October 27, 2004, ended November 10 with Sudan, SLA, and JEM signing security and humanitarian protocols.
A third, hopeful round of AU-lead peace talks began in Abuja on December 11, 2004, seeking a political settlement.
SLA and JEM pulled out of the peace talks on December 13, which were suspended until January, even as rebels vowed never to return until Sudan stopped attacking.
December 14-17 in Ndjamena, Darfur's National Movement for Reconstruction and Development signed a separate Chad-mediated peace pact with Sudan.
