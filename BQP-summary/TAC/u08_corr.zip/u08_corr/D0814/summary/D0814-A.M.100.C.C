Sudan and Darfur's two main rebel groups, the Sudan Liberation Army and the Justice and Equality Movement, signed a ceasefire in Ndjamena in April, 2004.
On October 6, the UK prime minister visited Sudan to discuss Darfur.
AU-lead peace talks in Abuja between those Darfur rebels and Sudan ran August 23 through September 17, reconvened October 21, but were suspended by the AU on October 27.
Libya hosted a "mini-summit" with leaders of Sudan, Egypt, Nigeria, Chad and the JEM in Tripoli on October 17-21; SLA declined.
EU and AU officials met October 23-24 in Khartoum with the Sudan President.
