By September 27, 2005 US Katrina deaths reached 1,121.
Rescuers searched for victims as successor Hurricane Rita struck.
By September 14 Brit Insurance forecast $US 50 billion global insurance losses.
Gulf of Mexico oil and natural gas extraction dropped sharply.
Refineries and chemical plants faltered.
US Agriculture lost $US 900 million.
In September Louisiana unemployment was 11.5%, from August's 5.7%. Turkey gave $US 1.5 million to the US Red Cross for Katrina relief and $US 1 million in humanitarian supplies.
Bosnia's Red Cross gave money.
On September 21, the US House passed $US 6.1 billion in Katrina recovery tax breaks.
