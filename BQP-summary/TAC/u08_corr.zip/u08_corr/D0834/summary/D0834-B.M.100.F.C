Defendants argued intelligent design is science, not religion, because its testable "irreducible complexity" claim implies an intelligent designer but not necessarily God.
One board member lied to hide that a church bought the "Pandas" books.
On December 20, 2005 the judge ruled that the board's action violates the constitution.
"Intelligent design is "a religious view, a mere re-labeling of creationism".
He excoriated board members for lying in their testimony, for not bothering to understand intelligent design and for the "breathtaking inanity of the Board's decision".
The ruling is binding only in one Pennsylvania district.
Dover will pay large legal fees.
