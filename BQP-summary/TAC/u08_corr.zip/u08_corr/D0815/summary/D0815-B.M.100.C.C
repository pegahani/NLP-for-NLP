Just prior to the successful May 24, 2005 cloture vote for the first judicial nominee under Senate consideration (Pricilla Owen for U.S. Appeals Court 5th Circuit) 14 moderate Senators confirmed their mutual pact to: vote for cloture in judicial confirmations, except in "extraordinary circumstances"; not change filibuster rules; and vote for cloture for three less contentious federal judicial nominees, including Brown and Owen.
On June 6, the Senate opened debate on Brown's confirmation.
On June 7, 10 Democrats joined in the successful vote for cloture for Brown.
On June 8, the Senate approved Brown's judicial appointment by 56-43.
