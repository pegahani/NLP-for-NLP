Armstrong sued SCA Promotions for breach of contract based on L'Equip's charges.
ICU's Verbruggen refuted WADA's Pound's claims Verbruggen gave L'Equip information linking Armstrong to positive 1999 erythropoietin results.
Verbruggen claimed Pound blocked ICU's investigation and made "transparently erroneous statements".
The International Olympic Athletes Commission and Summer Olympic Sports both demanded WADA's lab be suspended for illegally violating WADA code.
The IOC and the ICU each appointed independent investigators into all issues relating to the Tour's 1999 positive tests.
